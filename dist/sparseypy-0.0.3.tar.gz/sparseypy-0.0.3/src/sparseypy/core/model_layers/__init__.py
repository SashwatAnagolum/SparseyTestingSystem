# -*- coding: utf-8 -*-

"""
Init: initialization for the model_layers subpackage.
"""

from .sparsey_layer import SparseyLayer
