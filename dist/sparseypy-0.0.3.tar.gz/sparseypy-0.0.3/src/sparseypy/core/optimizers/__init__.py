# -*- coding: utf-8 -*-

"""
Init: initialization for te Optimizers module.
"""

from .hebbian import HebbianOptimizer
