# -*- coding: utf-8 -*-

"""
Init: initialization for the Model sub-package.
"""

from . import sparsey
