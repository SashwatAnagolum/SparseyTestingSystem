# -*- coding: utf-8 -*-

"""
Test Model Builder: code for testing the Model Builder class.
"""

import pytest
import torch


class TestModelBuilder:
    # def test_sparsey_model_valid_configs(self):


    # def test_sparsey_model_invalid_configs(self):
    pass
