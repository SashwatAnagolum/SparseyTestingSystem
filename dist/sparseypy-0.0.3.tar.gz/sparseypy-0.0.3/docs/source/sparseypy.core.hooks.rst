sparseypy.core.hooks package
============================

Submodules
----------

sparseypy.core.hooks.hook module
--------------------------------

.. automodule:: sparseypy.core.hooks.hook
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.hooks.hook\_factory module
-----------------------------------------

.. automodule:: sparseypy.core.hooks.hook_factory
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.hooks.layer\_io module
-------------------------------------

.. automodule:: sparseypy.core.hooks.layer_io
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: sparseypy.core.hooks
   :members:
   :undoc-members:
   :show-inheritance:
