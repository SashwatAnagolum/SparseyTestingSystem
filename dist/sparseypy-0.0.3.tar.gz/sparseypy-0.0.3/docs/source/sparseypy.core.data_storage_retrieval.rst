sparseypy.core.data\_storage\_retrieval package
===============================================

Submodules
----------

sparseypy.core.data\_storage\_retrieval.data\_fetcher module
------------------------------------------------------------

.. automodule:: sparseypy.core.data_storage_retrieval.data_fetcher
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.data\_storage\_retrieval.data\_storer module
-----------------------------------------------------------

.. automodule:: sparseypy.core.data_storage_retrieval.data_storer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: sparseypy.core.data_storage_retrieval
   :members:
   :undoc-members:
   :show-inheritance:
