sparseypy package
=================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   sparseypy.access_objects
   sparseypy.cli
   sparseypy.core
   sparseypy.tasks

Module contents
---------------

.. automodule:: sparseypy
   :members:
   :undoc-members:
   :show-inheritance:
