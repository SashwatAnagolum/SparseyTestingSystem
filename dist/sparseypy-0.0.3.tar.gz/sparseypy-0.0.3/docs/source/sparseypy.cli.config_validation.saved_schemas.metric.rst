sparseypy.cli.config\_validation.saved\_schemas.metric package
==============================================================

Submodules
----------

sparseypy.cli.config\_validation.saved\_schemas.metric.basis\_average module
----------------------------------------------------------------------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.metric.basis_average
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.cli.config\_validation.saved\_schemas.metric.basis\_set\_size module
------------------------------------------------------------------------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.metric.basis_set_size
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.cli.config\_validation.saved\_schemas.metric.basis\_set\_size\_increase module
----------------------------------------------------------------------------------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.metric.basis_set_size_increase
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.cli.config\_validation.saved\_schemas.metric.feature\_coverage module
-------------------------------------------------------------------------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.metric.feature_coverage
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.cli.config\_validation.saved\_schemas.metric.match\_accuracy module
-----------------------------------------------------------------------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.metric.match_accuracy
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.cli.config\_validation.saved\_schemas.metric.num\_activations module
------------------------------------------------------------------------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.metric.num_activations
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.metric
   :members:
   :undoc-members:
   :show-inheritance:
