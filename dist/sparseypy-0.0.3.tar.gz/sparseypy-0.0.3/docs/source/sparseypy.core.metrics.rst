sparseypy.core.metrics package
==============================

Submodules
----------

sparseypy.core.metrics.basis\_average module
--------------------------------------------

.. automodule:: sparseypy.core.metrics.basis_average
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.metrics.basis\_set\_size module
----------------------------------------------

.. automodule:: sparseypy.core.metrics.basis_set_size
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.metrics.basis\_set\_size\_increase module
--------------------------------------------------------

.. automodule:: sparseypy.core.metrics.basis_set_size_increase
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.metrics.comparisons module
-----------------------------------------

.. automodule:: sparseypy.core.metrics.comparisons
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.metrics.feature\_coverage module
-----------------------------------------------

.. automodule:: sparseypy.core.metrics.feature_coverage
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.metrics.match\_accuracy module
---------------------------------------------

.. automodule:: sparseypy.core.metrics.match_accuracy
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.metrics.metric\_factory module
---------------------------------------------

.. automodule:: sparseypy.core.metrics.metric_factory
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.metrics.metrics module
-------------------------------------

.. automodule:: sparseypy.core.metrics.metrics
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.core.metrics.num\_activations module
----------------------------------------------

.. automodule:: sparseypy.core.metrics.num_activations
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: sparseypy.core.metrics
   :members:
   :undoc-members:
   :show-inheritance:
