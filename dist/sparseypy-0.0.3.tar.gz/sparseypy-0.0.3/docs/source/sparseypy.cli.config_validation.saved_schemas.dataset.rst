sparseypy.cli.config\_validation.saved\_schemas.dataset package
===============================================================

Submodules
----------

sparseypy.cli.config\_validation.saved\_schemas.dataset.built\_in module
------------------------------------------------------------------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.dataset.built_in
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.cli.config\_validation.saved\_schemas.dataset.image module
--------------------------------------------------------------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.dataset.image
   :members:
   :undoc-members:
   :show-inheritance:

sparseypy.cli.config\_validation.saved\_schemas.dataset.sparsey module
----------------------------------------------------------------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.dataset.sparsey
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: sparseypy.cli.config_validation.saved_schemas.dataset
   :members:
   :undoc-members:
   :show-inheritance:
