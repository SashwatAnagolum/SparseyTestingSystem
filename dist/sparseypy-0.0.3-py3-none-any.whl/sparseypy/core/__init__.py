# -*- coding: utf-8 -*-

"""
Init: initialization for the core module of the sparsepy package.
"""