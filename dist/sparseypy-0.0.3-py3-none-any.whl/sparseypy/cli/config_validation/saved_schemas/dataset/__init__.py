"""
Dataset Schemas: for use in validating system dataset classes.
"""
from . import image, sparsey, built_in
