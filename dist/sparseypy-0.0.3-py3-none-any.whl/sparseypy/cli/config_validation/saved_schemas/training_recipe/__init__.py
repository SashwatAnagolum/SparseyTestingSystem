# -*- coding: utf-8 -*-

"""
Init: initialization for the Trainer sub-package.
"""

from . import sparsey
