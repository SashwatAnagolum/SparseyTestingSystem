# -*- coding: utf-8 -*-

"""
Sparsey Trainer Schema: the schema for Sparsey trainer config files.
"""


import typing

from schema import Schema, And, Optional

from ..abs_schema import AbstractSchema
from .....core.training import optimizers


class SparseyTrainerSchema(AbstractSchema):
    """
    SparseyTrainerSchema: schema for Sparsey trainers.
    """
    def extract_schema_params(self, config_info: dict) -> typing.Optional[dict]:
        """
        Extracts the required schema parameters from the config info dict
        in order to build the schema to validate against.

        Args:
            config_info: a dict containing the config info from the 
                user.

        Returns:
            a dict (might be None) containing all the required parameters 
                to build the schema.
        """
        schema_params = dict()

        schema_params['available_optimizers'] = []

        for optimizer_module in dir(optimizers):
            if optimizer_module[:2] != '__':
                schema_params['available_optimizers'].append(
                    optimizer_module
                )

        return schema_params


    def build_schema(self, schema_params: dict) -> Schema:
        """
        Builds a schema that can be used to validate the passed in
        config info.

        Args:
            schema_params: a dict containing all the required
                parameters to build the schema.

        Returns:
            a Schema that can be used to validate the config info.
        """
        config_schema = Schema(
            {
                'optimizer': And(
                    str,
                    lambda x: x in schema_params['allowed_optimizers']
                ),
                'metrics': [
                    {
                        'name': str,
                        Optional('save', default=False): bool
                    }
                ]
            }
        )

        return config_schema
