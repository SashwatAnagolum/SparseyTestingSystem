# -*- coding: utf-8 -*-

"""
Test Sparsey Model Configs: tests covering the config files for 
    customizing the structure of Sparsey models.
"""


import pytest

from sparsey.cli.config_validation.validate_config import validate_config


class TestSparseyModelConfigs:
    """
    TestSparseyModelConfigs: class containing a collection
    of tests related to config files for Sparsey model creation.
    """
    def __init__(self):
        pass

    @pytest.fixture
    def sparsey_model_schema_filepath(self) -> dict:
        """
        Returns a valid Sparsey model schema.

        Returns:
            a valid Sparsey model schema
        """
        valid_schema = {
            'input_dimensions': {
                'width': 28,
                'height': 28
            }, 
            'num_layers': 5,
            'layerwise_configs': {
                'num_macs': [50, 40, 30, 20, 10],
                'mac_grid_num_rows': [5, 4, 3, 2, 1],
                'mac_grid_num_cols': [10, 10, 10, 10],
                'num_cms_per_mac': [5, 5, 5, 5, 5],
                'num_neurons_per_cm': [10, 10, 10, 10, 10],
                'receptive_field_radii': [2.0, 2.0, 5.1, 3.2, 4.2]
            }
        }

        return valid_schema


    def test_valid_sparsey_model_schema(
            self, sparsey_model_schema: dict) -> None:
        """
        Tests the config file validation for the case
        where the config file for a Sparsey model is fully
        valid.

        Args:
            sparsey_model_schema: a dict containing the valid
            sparsey model schema to be used for testing, passed in 
            via pytest's fixture functionality.
        """
        assert validate_config(
            sparsey_model_schema, 'model',
            'sparsey_model'
        )[1]

    def test_missing_num_layers(self) -> None:
        pass

    def test_missing_input_dimensions(self) -> None:
        pass

    def test_missing_layerwise_configs(self) -> None:
        pass

    def test_incorrect_data_type_layerwise_configs(self) -> None:
        pass

    def test_incorrect_length_layerwise_configs(self) -> None:
        pass

    def test_negative_num_layers(self) -> None:
        pass

    def test_negative_layerwise_configs(self) -> None:
        pass
